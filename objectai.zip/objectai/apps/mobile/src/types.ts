// Ces types reflètent packages/shared-types. Dupliqués ici pour éviter la
// configuration Metro nécessaire au symlink monorepo ; à terme, une fois le
// bundler configuré, ce fichier pourra ré-exporter @objectai/shared-types.

export type ObjectCondition = "neuf" | "tres_bon_etat" | "bon_etat" | "usage" | "mauvais_etat";

export interface EstimatedValue {
  min: number;
  max: number;
  currency: string;
  confidence: number;
  factors: string[];
}

export interface AnalyzedObjectDraft {
  name: string;
  brand: string | null;
  model: string | null;
  category: string;
  description: string;
  characteristics: string[];
  condition: ObjectCondition;
  estimatedValue: EstimatedValue | null;
  confidenceScore: number;
}

export interface ObjectHistoryEntry {
  id: string;
  date: string;
  label: string;
  estimatedValue: { min: number; max: number } | null;
}

export type DocumentType = "facture" | "notice" | "certificat" | "garantie" | "photo" | "autre";

export interface ObjectDocument {
  id: string;
  type: DocumentType;
  fileUrl: string;
  createdAt: string;
}

export const DOCUMENT_TYPE_LABELS: Record<DocumentType, string> = {
  facture: "Facture",
  notice: "Notice",
  certificat: "Certificat",
  garantie: "Garantie",
  photo: "Photo supplémentaire",
  autre: "Autre",
};

export interface Reminder {
  id: string;
  message: string;
  dueAt: string;
}

export interface AnalyzedObject extends AnalyzedObjectDraft {
  id: string;
  photoUrl: string;
  createdAt: string;
  updatedAt: string;
  history?: ObjectHistoryEntry[];
  documents?: ObjectDocument[];
  reminders?: Reminder[];
}

export interface PurchaseAnalysis {
  verdict: string;
  isGoodPrice: boolean | null;
  estimatedValue: EstimatedValue | null;
  pointsToCheck: string[];
  questionsForSeller: string[];
  valueRiskFactors: string[];
}

export interface ListingDraft {
  title: string;
  description: string;
  mainCharacteristics: string[];
  condition: ObjectCondition;
  accessoriesIncluded: string[];
  importantNotes: string[];
  suggestedPrice: { min: number; max: number; currency: string };
}

export const CONDITION_LABELS: Record<ObjectCondition, string> = {
  neuf: "Neuf",
  tres_bon_etat: "Très bon état",
  bon_etat: "Bon état",
  usage: "Usagé",
  mauvais_etat: "Mauvais état",
};
