import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

const NOTIF_MAP_KEY = "objectai_reminder_notifications";

async function getMap(): Promise<Record<string, string>> {
  const raw = await AsyncStorage.getItem(NOTIF_MAP_KEY);
  return raw ? JSON.parse(raw) : {};
}

async function setMap(map: Record<string, string>) {
  await AsyncStorage.setItem(NOTIF_MAP_KEY, JSON.stringify(map));
}

export async function ensureNotificationPermission(): Promise<boolean> {
  const settings = await Notifications.getPermissionsAsync();
  if (settings.granted) return true;
  const request = await Notifications.requestPermissionsAsync();
  return request.granted;
}

if (Platform.OS === "android") {
  Notifications.setNotificationChannelAsync("default", {
    name: "Rappels ObjectAI",
    importance: Notifications.AndroidImportance.DEFAULT,
  });
}

export async function scheduleReminderNotification(
  reminderId: string,
  title: string,
  body: string,
  dueAt: Date
) {
  const granted = await ensureNotificationPermission();
  if (!granted) return;

  const notificationId = await Notifications.scheduleNotificationAsync({
    content: { title, body },
    trigger: dueAt,
  });

  const map = await getMap();
  map[reminderId] = notificationId;
  await setMap(map);
}

export async function cancelReminderNotification(reminderId: string) {
  const map = await getMap();
  const notificationId = map[reminderId];
  if (notificationId) {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
    delete map[reminderId];
    await setMap(map);
  }
}
