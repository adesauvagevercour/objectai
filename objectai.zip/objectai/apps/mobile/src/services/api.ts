// URL du backend. En développement, remplacer par l'IP locale de la machine
// qui fait tourner l'API (ex: http://192.168.1.10:4000) car "localhost"
// ne fonctionne pas depuis un téléphone physique.
export const API_URL = process.env.EXPO_PUBLIC_API_URL || "http://localhost:4000";

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
  token?: string | null;
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export async function apiFetch<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = "GET", body, token } = options;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 60000); // l'analyse IA peut prendre du temps

  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: controller.signal,
  }).finally(() => clearTimeout(timeout));

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const message = data?.error?.formErrors?.[0] || data?.error || "Une erreur est survenue.";
    throw new ApiError(res.status, typeof message === "string" ? message : "Une erreur est survenue.");
  }

  return data as T;
}
