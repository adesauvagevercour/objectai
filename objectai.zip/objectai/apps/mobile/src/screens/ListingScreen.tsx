import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Share,
} from "react-native";
import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import { ListingDraft } from "../types";

type Nav = NativeStackNavigationProp<RootStackParamList, "Listing">;
type ListingRoute = RouteProp<RootStackParamList, "Listing">;

export default function ListingScreen() {
  const navigation = useNavigation<Nav>();
  const { params } = useRoute<ListingRoute>();
  const [listing, setListing] = useState<ListingDraft>(params.listing);

  const update = <K extends keyof ListingDraft>(key: K, value: ListingDraft[K]) => {
    setListing((prev) => ({ ...prev, [key]: value }));
  };

  const composedText = [
    listing.title,
    "",
    listing.description,
    "",
    listing.mainCharacteristics.length ? "Caractéristiques :\n" + listing.mainCharacteristics.map((c) => `- ${c}`).join("\n") : "",
    listing.accessoriesIncluded.length ? "\nAccessoires inclus :\n" + listing.accessoriesIncluded.map((a) => `- ${a}`).join("\n") : "",
    listing.importantNotes.length ? "\nÀ savoir :\n" + listing.importantNotes.map((n) => `- ${n}`).join("\n") : "",
    `\nPrix : ${listing.suggestedPrice.min} à ${listing.suggestedPrice.max} ${listing.suggestedPrice.currency}`,
  ]
    .filter(Boolean)
    .join("\n");

  const handleShare = async () => {
    // L'app ne publie jamais automatiquement : le texte est simplement partagé
    // ou copié, à l'utilisateur de le poster où il le souhaite.
    await Share.share({ message: composedText });
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 60 }}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.back}>‹ Retour à la fiche</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Annonce de vente</Text>
      <Text style={styles.hint}>Relisez et modifiez le texte avant de le publier vous-même.</Text>

      <Text style={styles.label}>Titre</Text>
      <TextInput style={styles.input} value={listing.title} onChangeText={(v) => update("title", v)} />

      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, styles.inputMultiline]}
        value={listing.description}
        onChangeText={(v) => update("description", v)}
        multiline
      />

      <Text style={styles.label}>Caractéristiques (une par ligne)</Text>
      <TextInput
        style={[styles.input, styles.inputMultiline]}
        value={listing.mainCharacteristics.join("\n")}
        onChangeText={(v) => update("mainCharacteristics", v.split("\n").filter(Boolean))}
        multiline
      />

      <Text style={styles.label}>Accessoires inclus (un par ligne)</Text>
      <TextInput
        style={[styles.input, styles.inputMultiline]}
        value={listing.accessoriesIncluded.join("\n")}
        onChangeText={(v) => update("accessoriesIncluded", v.split("\n").filter(Boolean))}
        multiline
      />

      <Text style={styles.label}>À préciser à l'acheteur (une ligne par point)</Text>
      <TextInput
        style={[styles.input, styles.inputMultiline]}
        value={listing.importantNotes.join("\n")}
        onChangeText={(v) => update("importantNotes", v.split("\n").filter(Boolean))}
        multiline
      />

      <Text style={styles.label}>Prix conseillé</Text>
      <View style={styles.priceRow}>
        <TextInput
          style={[styles.input, styles.priceInput]}
          value={String(listing.suggestedPrice.min)}
          keyboardType="numeric"
          onChangeText={(v) =>
            update("suggestedPrice", { ...listing.suggestedPrice, min: Number(v) || 0 })
          }
        />
        <Text style={styles.priceSeparator}>à</Text>
        <TextInput
          style={[styles.input, styles.priceInput]}
          value={String(listing.suggestedPrice.max)}
          keyboardType="numeric"
          onChangeText={(v) =>
            update("suggestedPrice", { ...listing.suggestedPrice, max: Number(v) || 0 })
          }
        />
        <Text style={styles.priceCurrency}>{listing.suggestedPrice.currency}</Text>
      </View>

      <TouchableOpacity style={styles.shareButton} onPress={handleShare}>
        <Text style={styles.shareButtonText}>Partager l'annonce</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20, paddingTop: 60 },
  back: { color: "#6B7280", fontSize: 16, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: "700", color: "#111827" },
  hint: { fontSize: 13, color: "#6B7280", marginTop: 4, marginBottom: 16 },
  label: { fontSize: 13, fontWeight: "600", color: "#6B7280", marginTop: 14, marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    backgroundColor: "#F9FAFB",
    color: "#111827",
  },
  inputMultiline: { minHeight: 70, textAlignVertical: "top" },
  priceRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  priceInput: { flex: 1 },
  priceSeparator: { color: "#6B7280" },
  priceCurrency: { color: "#6B7280", fontWeight: "600" },
  shareButton: {
    backgroundColor: "#111827",
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: 28,
  },
  shareButtonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
});
