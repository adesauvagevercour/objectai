import React, { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Linking,
  TextInput,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import { useAuth } from "../context/AuthContext";
import { apiFetch, ApiError } from "../services/api";
import { scheduleReminderNotification, cancelReminderNotification } from "../services/notifications";
import {
  AnalyzedObject,
  CONDITION_LABELS,
  DocumentType,
  DOCUMENT_TYPE_LABELS,
  ObjectDocument,
  Reminder,
  ListingDraft,
} from "../types";

type Nav = NativeStackNavigationProp<RootStackParamList, "ObjectDetail">;
type DetailRoute = RouteProp<RootStackParamList, "ObjectDetail">;

export default function ObjectDetailScreen() {
  const navigation = useNavigation<Nav>();
  const { params } = useRoute<DetailRoute>();
  const { accessToken } = useAuth();
  const [object, setObject] = useState<AnalyzedObject | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [reminderMessage, setReminderMessage] = useState("");
  const [reminderDelay, setReminderDelay] = useState<number | null>(null); // en jours
  const [savingReminder, setSavingReminder] = useState(false);
  const [generatingListing, setGeneratingListing] = useState(false);

  const DELAY_OPTIONS: { label: string; days: number }[] = [
    { label: "7 jours", days: 7 },
    { label: "30 jours", days: 30 },
    { label: "3 mois", days: 90 },
    { label: "6 mois", days: 182 },
    { label: "1 an", days: 365 },
  ];

  const loadObject = useCallback(async () => {
    const data = await apiFetch<AnalyzedObject>(`/objects/${params.objectId}`, { token: accessToken });
    setObject(data);
  }, [params.objectId, accessToken]);

  useEffect(() => {
    (async () => {
      try {
        await loadObject();
      } finally {
        setLoading(false);
      }
    })();
  }, [loadObject]);

  const handleAddDocument = () => {
    const types: DocumentType[] = ["facture", "notice", "certificat", "garantie", "photo", "autre"];
    Alert.alert(
      "Ajouter un document",
      "Quel type de document ?",
      [
        ...types.map((type) => ({
          text: DOCUMENT_TYPE_LABELS[type],
          onPress: () => pickAndUploadDocument(type),
        })),
        { text: "Annuler", style: "cancel" as const },
      ]
    );
  };

  const pickAndUploadDocument = async (type: DocumentType) => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission refusée", "ObjectAI a besoin d'accéder à vos photos.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 0.6 });
    if (result.canceled || !result.assets?.[0]?.base64) return;

    setUploadingDoc(true);
    try {
      await apiFetch(`/objects/${params.objectId}/documents`, {
        method: "POST",
        token: accessToken,
        body: { type, fileBase64: `data:image/jpeg;base64,${result.assets[0].base64}` },
      });
      await loadObject();
    } catch (e) {
      Alert.alert("Erreur", e instanceof ApiError ? e.message : "L'ajout du document a échoué.");
    } finally {
      setUploadingDoc(false);
    }
  };

  const handleGenerateListing = async () => {
    setGeneratingListing(true);
    try {
      const listing = await apiFetch<ListingDraft>(`/objects/${params.objectId}/listing`, {
        method: "POST",
        token: accessToken,
      });
      navigation.navigate("Listing", { listing, objectId: params.objectId });
    } catch (e) {
      Alert.alert("Erreur", e instanceof ApiError ? e.message : "La génération de l'annonce a échoué.");
    } finally {
      setGeneratingListing(false);
    }
  };

  const handleAddReminder = async () => {
    if (!reminderMessage.trim() || !reminderDelay) {
      Alert.alert("Champs manquants", "Indiquez un message et une échéance.");
      return;
    }
    setSavingReminder(true);
    try {
      const dueAt = new Date();
      dueAt.setDate(dueAt.getDate() + reminderDelay);

      const reminder = await apiFetch<Reminder>(`/objects/${params.objectId}/reminders`, {
        method: "POST",
        token: accessToken,
        body: { message: reminderMessage.trim(), dueAt: dueAt.toISOString() },
      });

      await scheduleReminderNotification(
        reminder.id,
        object?.name ?? "Entretien",
        reminder.message,
        dueAt
      );

      setReminderMessage("");
      setReminderDelay(null);
      setShowReminderForm(false);
      await loadObject();
    } catch (e) {
      Alert.alert("Erreur", e instanceof ApiError ? e.message : "L'ajout du rappel a échoué.");
    } finally {
      setSavingReminder(false);
    }
  };

  const handleDeleteReminder = (reminder: Reminder) => {
    Alert.alert("Supprimer ce rappel ?", reminder.message, [
      { text: "Annuler", style: "cancel" },
      {
        text: "Supprimer",
        style: "destructive",
        onPress: async () => {
          try {
            await apiFetch(`/objects/${params.objectId}/reminders/${reminder.id}`, {
              method: "DELETE",
              token: accessToken,
            });
            await cancelReminderNotification(reminder.id);
            await loadObject();
          } catch (e) {
            Alert.alert("Erreur", e instanceof ApiError ? e.message : "La suppression a échoué.");
          }
        },
      },
    ]);
  };

  const handleDeleteDocument = (doc: ObjectDocument) => {
    Alert.alert("Supprimer ce document ?", DOCUMENT_TYPE_LABELS[doc.type], [
      { text: "Annuler", style: "cancel" },
      {
        text: "Supprimer",
        style: "destructive",
        onPress: async () => {
          try {
            await apiFetch(`/objects/${params.objectId}/documents/${doc.id}`, {
              method: "DELETE",
              token: accessToken,
            });
            await loadObject();
          } catch (e) {
            Alert.alert("Erreur", e instanceof ApiError ? e.message : "La suppression a échoué.");
          }
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (!object) {
    return (
      <View style={styles.center}>
        <Text>Objet introuvable.</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 60 }}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.back}>‹ Mes objets</Text>
      </TouchableOpacity>

      <Image source={{ uri: object.photoUrl }} style={styles.photo} />

      <Text style={styles.name}>{object.name}</Text>
      <Text style={styles.subtitle}>
        {[object.brand, object.model].filter(Boolean).join(" · ") || object.category}
      </Text>

      <View style={styles.badges}>
        <Text style={styles.badge}>{CONDITION_LABELS[object.condition]}</Text>
        <Text style={styles.badge}>{object.category}</Text>
      </View>

      <Text style={styles.sectionTitle}>Description</Text>
      <Text style={styles.body}>{object.description}</Text>

      {object.characteristics.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Caractéristiques</Text>
          {object.characteristics.map((c, i) => (
            <Text key={i} style={styles.bullet}>
              • {c}
            </Text>
          ))}
        </>
      )}

      <Text style={styles.sectionTitle}>Valeur estimée</Text>
      {object.estimatedValue ? (
        <Text style={styles.value}>
          {object.estimatedValue.min} € à {object.estimatedValue.max} €
        </Text>
      ) : (
        <Text style={styles.body}>Non estimée.</Text>
      )}

      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionTitleInline}>Documents</Text>
        <TouchableOpacity onPress={handleAddDocument} disabled={uploadingDoc}>
          {uploadingDoc ? (
            <ActivityIndicator size="small" />
          ) : (
            <Text style={styles.addDocLink}>＋ Ajouter</Text>
          )}
        </TouchableOpacity>
      </View>
      {object.documents && object.documents.length > 0 ? (
        object.documents.map((doc) => (
          <View key={doc.id} style={styles.docRow}>
            <TouchableOpacity style={styles.docInfo} onPress={() => Linking.openURL(doc.fileUrl)}>
              <Text style={styles.docType}>{DOCUMENT_TYPE_LABELS[doc.type]}</Text>
              <Text style={styles.docDate}>
                {new Date(doc.createdAt).toLocaleDateString("fr-FR")}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleDeleteDocument(doc)}>
              <Text style={styles.docDelete}>Supprimer</Text>
            </TouchableOpacity>
          </View>
        ))
      ) : (
        <Text style={styles.body}>Aucun document ajouté pour cet objet.</Text>
      )}

      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionTitleInline}>Entretien & rappels</Text>
        <TouchableOpacity onPress={() => setShowReminderForm((v) => !v)}>
          <Text style={styles.addDocLink}>{showReminderForm ? "Fermer" : "＋ Ajouter"}</Text>
        </TouchableOpacity>
      </View>

      {showReminderForm && (
        <View style={styles.reminderForm}>
          <TextInput
            style={styles.input}
            placeholder="Ex : Vérifier la pile de cette montre"
            value={reminderMessage}
            onChangeText={setReminderMessage}
          />
          <View style={styles.chipRow}>
            {DELAY_OPTIONS.map((opt) => (
              <TouchableOpacity
                key={opt.days}
                style={[styles.chip, reminderDelay === opt.days && styles.chipActive]}
                onPress={() => setReminderDelay(opt.days)}
              >
                <Text style={[styles.chipText, reminderDelay === opt.days && styles.chipTextActive]}>
                  {opt.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity
            style={styles.reminderSubmit}
            onPress={handleAddReminder}
            disabled={savingReminder}
          >
            {savingReminder ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.reminderSubmitText}>Programmer le rappel</Text>
            )}
          </TouchableOpacity>
        </View>
      )}

      {object.reminders && object.reminders.length > 0 ? (
        object.reminders.map((reminder) => (
          <View key={reminder.id} style={styles.docRow}>
            <View style={styles.docInfo}>
              <Text style={styles.docType}>{reminder.message}</Text>
              <Text style={styles.docDate}>
                {new Date(reminder.dueAt).toLocaleDateString("fr-FR")}
              </Text>
            </View>
            <TouchableOpacity onPress={() => handleDeleteReminder(reminder)}>
              <Text style={styles.docDelete}>Supprimer</Text>
            </TouchableOpacity>
          </View>
        ))
      ) : (
        !showReminderForm && <Text style={styles.body}>Aucun rappel programmé.</Text>
      )}

      {object.history && object.history.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Historique</Text>
          {object.history.map((h) => (
            <View key={h.id} style={styles.historyRow}>
              <Text style={styles.historyDate}>
                {new Date(h.date).toLocaleDateString("fr-FR")}
              </Text>
              <Text style={styles.historyLabel}>{h.label}</Text>
              {h.estimatedValue && (
                <Text style={styles.historyValue}>
                  {h.estimatedValue.min} € – {h.estimatedValue.max} €
                </Text>
              )}
            </View>
          ))}
        </>
      )}

      <TouchableOpacity
        style={styles.sellButton}
        onPress={handleGenerateListing}
        disabled={generatingListing}
      >
        {generatingListing ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.sellButtonText}>Vendre cet objet</Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20, paddingTop: 60 },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  back: { color: "#6B7280", fontSize: 16, marginBottom: 16 },
  photo: { width: "100%", height: 240, borderRadius: 16, backgroundColor: "#F3F4F6" },
  name: { fontSize: 22, fontWeight: "700", color: "#111827", marginTop: 16 },
  subtitle: { fontSize: 14, color: "#6B7280", marginTop: 2 },
  badges: { flexDirection: "row", gap: 8, marginTop: 12 },
  badge: {
    fontSize: 12,
    color: "#374151",
    backgroundColor: "#F3F4F6",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  sectionTitle: { fontSize: 13, fontWeight: "600", color: "#6B7280", marginTop: 20, marginBottom: 6 },
  sectionTitleInline: { fontSize: 13, fontWeight: "600", color: "#6B7280" },
  sectionHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 20,
  },
  addDocLink: { fontSize: 13, fontWeight: "600", color: "#111827" },
  docRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: "#F3F4F6",
    paddingVertical: 10,
  },
  docInfo: { flex: 1 },
  docType: { fontSize: 14, color: "#111827", fontWeight: "500" },
  docDate: { fontSize: 12, color: "#9CA3AF", marginTop: 2 },
  docDelete: { fontSize: 13, color: "#DC2626" },
  input: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    backgroundColor: "#F9FAFB",
    color: "#111827",
  },
  reminderForm: { backgroundColor: "#F9FAFB", borderRadius: 12, padding: 12, marginTop: 10 },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 10 },
  chip: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 7,
    backgroundColor: "#fff",
  },
  chipActive: { backgroundColor: "#111827", borderColor: "#111827" },
  chipText: { fontSize: 13, color: "#111827" },
  chipTextActive: { color: "#fff" },
  reminderSubmit: {
    backgroundColor: "#111827",
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
    marginTop: 12,
  },
  reminderSubmitText: { color: "#fff", fontWeight: "600", fontSize: 14 },
  body: { fontSize: 14, color: "#374151", lineHeight: 20 },
  bullet: { fontSize: 14, color: "#374151", marginBottom: 4 },
  value: { fontSize: 20, fontWeight: "700", color: "#059669" },
  historyRow: { borderTopWidth: 1, borderTopColor: "#F3F4F6", paddingVertical: 10 },
  historyDate: { fontSize: 12, color: "#9CA3AF" },
  historyLabel: { fontSize: 14, color: "#111827", fontWeight: "500", marginTop: 2 },
  historyValue: { fontSize: 13, color: "#059669", marginTop: 2 },
  sellButton: {
    backgroundColor: "#111827",
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: 28,
  },
  sellButtonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
});
