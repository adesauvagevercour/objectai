import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  ActivityIndicator,
  Alert,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import { useAuth } from "../context/AuthContext";
import { apiFetch, ApiError } from "../services/api";
import { AnalyzedObjectDraft } from "../types";

type Nav = NativeStackNavigationProp<RootStackParamList, "Capture">;

export default function CaptureScreen() {
  const navigation = useNavigation<Nav>();
  const { accessToken } = useAuth();
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const pickFrom = async (source: "camera" | "gallery") => {
    const permission =
      source === "camera"
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permission.granted) {
      Alert.alert(
        "Permission refusée",
        "ObjectAI a besoin de cet accès pour analyser votre objet."
      );
      return;
    }

    const result =
      source === "camera"
        ? await ImagePicker.launchCameraAsync({ base64: true, quality: 0.6 })
        : await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 0.6 });

    if (result.canceled || !result.assets?.[0]) return;

    const asset = result.assets[0];
    setPhotoUri(asset.uri);
    await analyze(asset.uri, asset.base64 ?? null);
  };

  const analyze = async (uri: string, base64: string | null) => {
    if (!base64) {
      Alert.alert("Erreur", "Impossible de lire cette photo. Réessayez.");
      return;
    }
    setAnalyzing(true);
    try {
      const draft = await apiFetch<AnalyzedObjectDraft>("/objects/analyze", {
        method: "POST",
        token: accessToken,
        body: { image: base64 },
      });
      navigation.navigate("Result", { draft, photoUri: uri, photoBase64: base64 });
    } catch (e) {
      Alert.alert(
        "Analyse impossible",
        e instanceof ApiError ? e.message : "Vérifiez votre connexion et réessayez."
      );
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.back}>‹ Retour</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Analyser un objet</Text>

      {photoUri && <Image source={{ uri: photoUri }} style={styles.preview} />}

      {analyzing ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#111827" />
          <Text style={styles.analyzingText}>Analyse en cours…</Text>
        </View>
      ) : (
        <View style={styles.actions}>
          <TouchableOpacity style={styles.button} onPress={() => pickFrom("camera")}>
            <Text style={styles.buttonText}>📷 Prendre une photo</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, styles.secondary]}
            onPress={() => pickFrom("gallery")}
          >
            <Text style={[styles.buttonText, styles.secondaryText]}>
              🖼️ Choisir dans la galerie
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20, paddingTop: 60 },
  back: { color: "#6B7280", fontSize: 16, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: "700", color: "#111827", marginBottom: 24 },
  preview: {
    width: "100%",
    height: 260,
    borderRadius: 16,
    marginBottom: 24,
    backgroundColor: "#F3F4F6",
  },
  actions: { gap: 12 },
  button: { backgroundColor: "#111827", borderRadius: 12, paddingVertical: 16, alignItems: "center" },
  secondary: { backgroundColor: "#F3F4F6" },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  secondaryText: { color: "#111827" },
  center: { alignItems: "center", marginTop: 40 },
  analyzingText: { marginTop: 12, color: "#6B7280" },
});
