import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { useNavigation, CompositeNavigationProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { BottomTabNavigationProp } from "@react-navigation/bottom-tabs";
import { useAuth } from "../context/AuthContext";
import { RootStackParamList } from "../navigation/AppNavigator";
import { MainTabParamList } from "../navigation/MainTabs";

// Home vit à l'intérieur de la barre d'onglets (Main), mais doit aussi
// pouvoir pousser des écrans de la pile racine (Capture, Purchase) qui
// n'ont pas de barre d'onglets. D'où la navigation composite.
type Nav = CompositeNavigationProp<
  BottomTabNavigationProp<MainTabParamList, "Home">,
  NativeStackNavigationProp<RootStackParamList>
>;

export default function HomeScreen() {
  const { user, logout } = useAuth();
  const navigation = useNavigation<Nav>();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Bonjour {user?.name} 👋</Text>
        <TouchableOpacity onPress={logout}>
          <Text style={styles.logout}>Déconnexion</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.myObjectsLink} onPress={() => navigation.navigate("Purchase")}>
        <Text style={styles.myObjectsLinkText}>Analyser un achat →</Text>
      </TouchableOpacity>

      <View style={styles.center}>
        <TouchableOpacity
          style={styles.mainButton}
          activeOpacity={0.85}
          onPress={() => navigation.navigate("Capture")}
        >
          <Text style={styles.mainButtonIcon}>📷</Text>
          <Text style={styles.mainButtonText}>Analyser un objet</Text>
        </TouchableOpacity>
        <Text style={styles.hint}>
          Photographiez un objet pour obtenir sa fiche complète et son estimation.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", paddingHorizontal: 20, paddingTop: 60 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  greeting: { fontSize: 18, fontWeight: "600", color: "#111827" },
  logout: { color: "#6B7280", fontSize: 14 },
  myObjectsLink: { marginTop: 20 },
  myObjectsLinkText: { color: "#111827", fontSize: 14, fontWeight: "600" },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  mainButton: {
    backgroundColor: "#111827",
    width: 200,
    height: 200,
    borderRadius: 100,
    justifyContent: "center",
    alignItems: "center",
  },
  mainButtonIcon: { fontSize: 40, marginBottom: 8 },
  mainButtonText: { color: "#fff", fontSize: 16, fontWeight: "600", textAlign: "center", paddingHorizontal: 16 },
  hint: { marginTop: 24, textAlign: "center", color: "#6B7280", fontSize: 14, paddingHorizontal: 24 },
});
