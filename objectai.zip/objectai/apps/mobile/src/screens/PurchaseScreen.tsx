import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  ActivityIndicator,
  Alert,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import { useAuth } from "../context/AuthContext";
import { apiFetch, ApiError } from "../services/api";
import { PurchaseAnalysis } from "../types";

type Nav = NativeStackNavigationProp<RootStackParamList, "Purchase">;

export default function PurchaseScreen() {
  const navigation = useNavigation<Nav>();
  const { accessToken } = useAuth();
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [photoBase64, setPhotoBase64] = useState<string | null>(null);
  const [askingPrice, setAskingPrice] = useState("");
  const [analyzing, setAnalyzing] = useState(false);

  const pickFrom = async (source: "camera" | "gallery") => {
    const permission =
      source === "camera"
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permission.granted) {
      Alert.alert("Permission refusée", "ObjectAI a besoin de cet accès pour analyser la photo.");
      return;
    }

    const result =
      source === "camera"
        ? await ImagePicker.launchCameraAsync({ base64: true, quality: 0.6 })
        : await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 0.6 });

    if (result.canceled || !result.assets?.[0]) return;

    setPhotoUri(result.assets[0].uri);
    setPhotoBase64(result.assets[0].base64 ?? null);
  };

  const handleAnalyze = async () => {
    if (!photoBase64) {
      Alert.alert("Photo manquante", "Prenez ou choisissez d'abord une photo.");
      return;
    }
    setAnalyzing(true);
    try {
      const priceNumber = askingPrice ? Number(askingPrice.replace(",", ".")) : undefined;
      const analysis = await apiFetch<PurchaseAnalysis>("/purchase/analyze", {
        method: "POST",
        token: accessToken,
        body: { image: photoBase64, askingPrice: priceNumber },
      });
      navigation.navigate("PurchaseResult", { analysis, photoUri: photoUri! });
    } catch (e) {
      Alert.alert(
        "Analyse impossible",
        e instanceof ApiError ? e.message : "Vérifiez votre connexion et réessayez."
      );
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.back}>‹ Retour</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Analyser un achat</Text>
      <Text style={styles.hint}>
        Photographiez l'objet ou l'annonce du vendeur pour savoir si c'est une bonne affaire.
      </Text>

      {photoUri && <Image source={{ uri: photoUri }} style={styles.preview} />}

      {!analyzing && (
        <>
          <View style={styles.actions}>
            <TouchableOpacity style={styles.button} onPress={() => pickFrom("camera")}>
              <Text style={styles.buttonText}>📷 Prendre une photo</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button, styles.secondary]} onPress={() => pickFrom("gallery")}>
              <Text style={[styles.buttonText, styles.secondaryText]}>🖼️ Choisir dans la galerie</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.label}>Prix demandé par le vendeur (optionnel)</Text>
          <TextInput
            style={styles.input}
            placeholder="Ex : 250"
            value={askingPrice}
            onChangeText={setAskingPrice}
            keyboardType="numeric"
          />

          <TouchableOpacity
            style={[styles.button, styles.analyzeButton, !photoBase64 && styles.disabled]}
            onPress={handleAnalyze}
            disabled={!photoBase64}
          >
            <Text style={styles.buttonText}>Analyser</Text>
          </TouchableOpacity>
        </>
      )}

      {analyzing && (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#111827" />
          <Text style={styles.analyzingText}>Analyse en cours…</Text>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20, paddingTop: 60 },
  back: { color: "#6B7280", fontSize: 16, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: "700", color: "#111827" },
  hint: { fontSize: 14, color: "#6B7280", marginTop: 6, marginBottom: 20, lineHeight: 20 },
  preview: { width: "100%", height: 220, borderRadius: 16, marginBottom: 20, backgroundColor: "#F3F4F6" },
  actions: { gap: 12, marginBottom: 20 },
  button: { backgroundColor: "#111827", borderRadius: 12, paddingVertical: 16, alignItems: "center" },
  secondary: { backgroundColor: "#F3F4F6" },
  analyzeButton: { marginTop: 20 },
  disabled: { opacity: 0.4 },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  secondaryText: { color: "#111827" },
  label: { fontSize: 13, fontWeight: "600", color: "#6B7280", marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    backgroundColor: "#F9FAFB",
  },
  center: { alignItems: "center", marginTop: 40 },
  analyzingText: { marginTop: 12, color: "#6B7280" },
});
