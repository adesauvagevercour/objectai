import React from "react";
import { View, Text, Image, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";

type Nav = NativeStackNavigationProp<RootStackParamList, "PurchaseResult">;
type ResultRoute = RouteProp<RootStackParamList, "PurchaseResult">;

export default function PurchaseResultScreen() {
  const navigation = useNavigation<Nav>();
  const { params } = useRoute<ResultRoute>();
  const { analysis } = params;

  const verdictLabel =
    analysis.isGoodPrice === true
      ? "Prix intéressant"
      : analysis.isGoodPrice === false
      ? "Prix élevé"
      : "Prix non évalué";
  const verdictColor =
    analysis.isGoodPrice === true ? "#059669" : analysis.isGoodPrice === false ? "#DC2626" : "#6B7280";

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 60 }}>
      <TouchableOpacity onPress={() => navigation.navigate("Main")}>
        <Text style={styles.back}>‹ Accueil</Text>
      </TouchableOpacity>

      <Image source={{ uri: params.photoUri }} style={styles.photo} />

      <View style={[styles.badge, { backgroundColor: `${verdictColor}1A` }]}>
        <Text style={[styles.badgeText, { color: verdictColor }]}>{verdictLabel}</Text>
      </View>

      <Text style={styles.sectionTitle}>Avis général</Text>
      <Text style={styles.body}>{analysis.verdict}</Text>

      {analysis.estimatedValue && (
        <>
          <Text style={styles.sectionTitle}>Valeur estimée</Text>
          <Text style={styles.value}>
            {analysis.estimatedValue.min} € à {analysis.estimatedValue.max} €
          </Text>
        </>
      )}

      {analysis.pointsToCheck.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Points à vérifier</Text>
          {analysis.pointsToCheck.map((p, i) => (
            <Text key={i} style={styles.bullet}>
              • {p}
            </Text>
          ))}
        </>
      )}

      {analysis.questionsForSeller.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Questions à poser au vendeur</Text>
          {analysis.questionsForSeller.map((q, i) => (
            <Text key={i} style={styles.bullet}>
              • {q}
            </Text>
          ))}
        </>
      )}

      {analysis.valueRiskFactors.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Ce qui pourrait diminuer la valeur</Text>
          {analysis.valueRiskFactors.map((f, i) => (
            <Text key={i} style={styles.bullet}>
              • {f}
            </Text>
          ))}
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20, paddingTop: 60 },
  back: { color: "#6B7280", fontSize: 16, marginBottom: 16 },
  photo: { width: "100%", height: 220, borderRadius: 16, backgroundColor: "#F3F4F6" },
  badge: { alignSelf: "flex-start", borderRadius: 999, paddingHorizontal: 14, paddingVertical: 8, marginTop: 16 },
  badgeText: { fontSize: 14, fontWeight: "700" },
  sectionTitle: { fontSize: 13, fontWeight: "600", color: "#6B7280", marginTop: 20, marginBottom: 6 },
  body: { fontSize: 14, color: "#374151", lineHeight: 20 },
  bullet: { fontSize: 14, color: "#374151", marginBottom: 4 },
  value: { fontSize: 20, fontWeight: "700", color: "#111827" },
});
