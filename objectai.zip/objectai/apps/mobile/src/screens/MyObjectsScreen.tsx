import React, { useCallback, useState } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { useFocusEffect, useNavigation, CompositeNavigationProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { BottomTabNavigationProp } from "@react-navigation/bottom-tabs";
import { RootStackParamList } from "../navigation/AppNavigator";
import { MainTabParamList } from "../navigation/MainTabs";
import { useAuth } from "../context/AuthContext";
import { apiFetch } from "../services/api";
import { AnalyzedObject, CONDITION_LABELS } from "../types";

type Nav = CompositeNavigationProp<
  BottomTabNavigationProp<MainTabParamList, "MyObjects">,
  NativeStackNavigationProp<RootStackParamList>
>;

export default function MyObjectsScreen() {
  const navigation = useNavigation<Nav>();
  const { accessToken } = useAuth();
  const [objects, setObjects] = useState<AnalyzedObject[] | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await apiFetch<AnalyzedObject[]>("/objects", { token: accessToken });
      setObjects(data);
    } catch {
      setObjects([]);
    }
  }, [accessToken]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Mes objets</Text>
        <TouchableOpacity onPress={() => navigation.navigate("Capture")}>
          <Text style={styles.add}>＋</Text>
        </TouchableOpacity>
      </View>

      {objects === null ? (
        <ActivityIndicator style={{ marginTop: 40 }} size="large" />
      ) : objects.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>
            Vous n'avez pas encore analysé d'objet.{"\n"}Lancez une analyse pour commencer votre collection.
          </Text>
          <TouchableOpacity style={styles.emptyButton} onPress={() => navigation.navigate("Capture")}>
            <Text style={styles.emptyButtonText}>Analyser un objet</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={objects}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: 40 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate("ObjectDetail", { objectId: item.id })}
            >
              <Image source={{ uri: item.photoUrl }} style={styles.cardImage} />
              <View style={styles.cardBody}>
                <Text style={styles.cardName} numberOfLines={1}>
                  {item.name}
                </Text>
                <Text style={styles.cardCondition}>{CONDITION_LABELS[item.condition]}</Text>
                <Text style={styles.cardValue}>
                  {item.estimatedValue
                    ? `${item.estimatedValue.min} € – ${item.estimatedValue.max} €`
                    : "Valeur non estimée"}
                </Text>
                <Text style={styles.cardDate}>
                  Analysé le {new Date(item.createdAt).toLocaleDateString("fr-FR")}
                </Text>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", paddingHorizontal: 20, paddingTop: 60 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  back: { color: "#6B7280", fontSize: 15 },
  title: { fontSize: 18, fontWeight: "700", color: "#111827" },
  add: { fontSize: 24, color: "#111827" },
  empty: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 20 },
  emptyText: { textAlign: "center", color: "#6B7280", marginBottom: 20, lineHeight: 20 },
  emptyButton: { backgroundColor: "#111827", borderRadius: 12, paddingVertical: 14, paddingHorizontal: 24 },
  emptyButtonText: { color: "#fff", fontWeight: "600" },
  card: {
    flexDirection: "row",
    backgroundColor: "#F9FAFB",
    borderRadius: 14,
    marginBottom: 12,
    overflow: "hidden",
  },
  cardImage: { width: 88, height: 88, backgroundColor: "#E5E7EB" },
  cardBody: { flex: 1, padding: 12, justifyContent: "center" },
  cardName: { fontSize: 15, fontWeight: "600", color: "#111827" },
  cardCondition: { fontSize: 12, color: "#6B7280", marginTop: 2 },
  cardValue: { fontSize: 14, fontWeight: "600", color: "#059669", marginTop: 4 },
  cardDate: { fontSize: 11, color: "#9CA3AF", marginTop: 4 },
});
