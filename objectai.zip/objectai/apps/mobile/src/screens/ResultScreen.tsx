import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import { AnalyzedObjectDraft, CONDITION_LABELS, ObjectCondition } from "../types";
import { useAuth } from "../context/AuthContext";
import { apiFetch, ApiError } from "../services/api";

type Nav = NativeStackNavigationProp<RootStackParamList, "Result">;
type ResultRoute = RouteProp<RootStackParamList, "Result">;

const CONDITIONS: ObjectCondition[] = ["neuf", "tres_bon_etat", "bon_etat", "usage", "mauvais_etat"];

export default function ResultScreen() {
  const navigation = useNavigation<Nav>();
  const { params } = useRoute<ResultRoute>();
  const { accessToken } = useAuth();
  const [draft, setDraft] = useState<AnalyzedObjectDraft>(params.draft);
  const [saving, setSaving] = useState(false);

  const confidencePct = Math.round(draft.confidenceScore * 100);

  const update = <K extends keyof AnalyzedObjectDraft>(key: K, value: AnalyzedObjectDraft[K]) => {
    setDraft((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await apiFetch("/objects", {
        method: "POST",
        token: accessToken,
        body: { ...draft, photoBase64: params.photoBase64 },
      });
      navigation.reset({
        index: 0,
        routes: [{ name: "Main", state: { routes: [{ name: "MyObjects" }] } }],
      });
    } catch (e) {
      Alert.alert(
        "Enregistrement impossible",
        e instanceof ApiError ? e.message : "Vérifiez votre connexion et réessayez."
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 60 }}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.back}>‹ Reprendre une photo</Text>
      </TouchableOpacity>

      <Image source={{ uri: params.photoUri }} style={styles.photo} />

      <View style={styles.confidenceBadge}>
        <Text style={styles.confidenceText}>Confiance de l'identification : {confidencePct}%</Text>
      </View>

      <Field label="Nom" value={draft.name} onChangeText={(v) => update("name", v)} />
      <View style={styles.row}>
        <Field
          label="Marque"
          value={draft.brand ?? ""}
          onChangeText={(v) => update("brand", v || null)}
          style={styles.half}
        />
        <Field
          label="Modèle"
          value={draft.model ?? ""}
          onChangeText={(v) => update("model", v || null)}
          style={styles.half}
        />
      </View>
      <Field label="Catégorie" value={draft.category} onChangeText={(v) => update("category", v)} />
      <Field
        label="Description"
        value={draft.description}
        onChangeText={(v) => update("description", v)}
        multiline
      />

      <Text style={styles.label}>État</Text>
      <View style={styles.conditionRow}>
        {CONDITIONS.map((c) => (
          <TouchableOpacity
            key={c}
            style={[styles.conditionChip, draft.condition === c && styles.conditionChipActive]}
            onPress={() => update("condition", c)}
          >
            <Text
              style={[
                styles.conditionChipText,
                draft.condition === c && styles.conditionChipTextActive,
              ]}
            >
              {CONDITION_LABELS[c]}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {draft.characteristics.length > 0 && (
        <>
          <Text style={styles.label}>Caractéristiques</Text>
          {draft.characteristics.map((c, i) => (
            <Text key={i} style={styles.bullet}>
              • {c}
            </Text>
          ))}
        </>
      )}

      <Text style={styles.label}>Valeur estimée</Text>
      {draft.estimatedValue ? (
        <View style={styles.valueBox}>
          <Text style={styles.valueText}>
            {draft.estimatedValue.min} € à {draft.estimatedValue.max} €
          </Text>
          {draft.estimatedValue.factors.length > 0 && (
            <Text style={styles.valueFactors}>
              Basé sur : {draft.estimatedValue.factors.join(", ")}
            </Text>
          )}
          <Text style={styles.disclaimer}>
            Estimation indicative, pas un prix garanti.
          </Text>
        </View>
      ) : (
        <Text style={styles.noValue}>
          Pas assez d'informations pour estimer une valeur fiable.
        </Text>
      )}

      <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={saving}>
        {saving ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.saveButtonText}>Enregistrer dans « Mes objets »</Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
}

function Field({
  label,
  value,
  onChangeText,
  multiline,
  style,
}: {
  label: string;
  value: string;
  onChangeText: (v: string) => void;
  multiline?: boolean;
  style?: object;
}) {
  return (
    <View style={style}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={[styles.input, multiline && styles.inputMultiline]}
        value={value}
        onChangeText={onChangeText}
        multiline={multiline}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20, paddingTop: 60 },
  back: { color: "#6B7280", fontSize: 16, marginBottom: 16 },
  photo: { width: "100%", height: 220, borderRadius: 16, backgroundColor: "#F3F4F6" },
  confidenceBadge: {
    alignSelf: "flex-start",
    backgroundColor: "#EFF6FF",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginTop: 12,
    marginBottom: 8,
  },
  confidenceText: { color: "#1D4ED8", fontSize: 12, fontWeight: "600" },
  label: { fontSize: 13, fontWeight: "600", color: "#6B7280", marginTop: 16, marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    backgroundColor: "#F9FAFB",
    color: "#111827",
  },
  inputMultiline: { minHeight: 80, textAlignVertical: "top" },
  row: { flexDirection: "row", gap: 12 },
  half: { flex: 1 },
  conditionRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  conditionChip: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  conditionChipActive: { backgroundColor: "#111827", borderColor: "#111827" },
  conditionChipText: { fontSize: 13, color: "#111827" },
  conditionChipTextActive: { color: "#fff" },
  bullet: { fontSize: 14, color: "#374151", marginBottom: 4 },
  valueBox: { backgroundColor: "#F9FAFB", borderRadius: 12, padding: 16 },
  valueText: { fontSize: 20, fontWeight: "700", color: "#111827" },
  valueFactors: { fontSize: 13, color: "#6B7280", marginTop: 6 },
  disclaimer: { fontSize: 12, color: "#9CA3AF", marginTop: 8, fontStyle: "italic" },
  noValue: { fontSize: 14, color: "#6B7280" },
  saveButton: {
    backgroundColor: "#111827",
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: 28,
  },
  saveButtonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
});
