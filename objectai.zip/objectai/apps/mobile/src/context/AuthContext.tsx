import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { apiFetch } from "../services/api";

interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

interface AuthContextValue {
  user: User | null;
  accessToken: string | null;
  isLoading: boolean;
  signup: (email: string, password: string, name: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const STORAGE_KEY = "objectai_auth";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [refreshToken, setRefreshToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          setUser(parsed.user);
          setAccessToken(parsed.accessToken);
          setRefreshToken(parsed.refreshToken);
        }
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  const persist = useCallback(async (u: User, access: string, refresh: string) => {
    setUser(u);
    setAccessToken(access);
    setRefreshToken(refresh);
    await AsyncStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ user: u, accessToken: access, refreshToken: refresh })
    );
  }, []);

  const signup = useCallback(
    async (email: string, password: string, name: string) => {
      const res = await apiFetch<{ user: User; tokens: { accessToken: string; refreshToken: string } }>(
        "/auth/signup",
        { method: "POST", body: { email, password, name } }
      );
      await persist(res.user, res.tokens.accessToken, res.tokens.refreshToken);
    },
    [persist]
  );

  const login = useCallback(
    async (email: string, password: string) => {
      const res = await apiFetch<{ user: User; tokens: { accessToken: string; refreshToken: string } }>(
        "/auth/login",
        { method: "POST", body: { email, password } }
      );
      await persist(res.user, res.tokens.accessToken, res.tokens.refreshToken);
    },
    [persist]
  );

  const logout = useCallback(async () => {
    setUser(null);
    setAccessToken(null);
    setRefreshToken(null);
    await AsyncStorage.removeItem(STORAGE_KEY);
  }, []);

  return (
    <AuthContext.Provider value={{ user, accessToken, isLoading, signup, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth doit être utilisé dans un AuthProvider");
  return ctx;
}
