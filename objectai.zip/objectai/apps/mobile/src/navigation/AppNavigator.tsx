import React from "react";
import { ActivityIndicator, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useAuth } from "../context/AuthContext";
import AuthScreen from "../screens/AuthScreen";
import MainTabs from "./MainTabs";
import CaptureScreen from "../screens/CaptureScreen";
import ResultScreen from "../screens/ResultScreen";
import ObjectDetailScreen from "../screens/ObjectDetailScreen";
import PurchaseScreen from "../screens/PurchaseScreen";
import PurchaseResultScreen from "../screens/PurchaseResultScreen";
import ListingScreen from "../screens/ListingScreen";
import { AnalyzedObjectDraft, ListingDraft, PurchaseAnalysis } from "../types";

// "Main" englobe la barre d'onglets (Accueil / Analyser / Mes objets / Profil).
// Les écrans ci-dessous vivent au-dessus, dans la pile racine, car ils ne
// doivent pas afficher la barre d'onglets (capture, résultats, fiche objet...).
export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
  Capture: undefined;
  Result: { draft: AnalyzedObjectDraft; photoUri: string; photoBase64: string };
  ObjectDetail: { objectId: string };
  Purchase: undefined;
  PurchaseResult: { analysis: PurchaseAnalysis; photoUri: string };
  Listing: { listing: ListingDraft; objectId: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {user ? (
          <>
            <Stack.Screen name="Main" component={MainTabs} />
            <Stack.Screen name="Capture" component={CaptureScreen} />
            <Stack.Screen name="Result" component={ResultScreen} />
            <Stack.Screen name="ObjectDetail" component={ObjectDetailScreen} />
            <Stack.Screen name="Purchase" component={PurchaseScreen} />
            <Stack.Screen name="PurchaseResult" component={PurchaseResultScreen} />
            <Stack.Screen name="Listing" component={ListingScreen} />
          </>
        ) : (
          <Stack.Screen name="Auth" component={AuthScreen} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
