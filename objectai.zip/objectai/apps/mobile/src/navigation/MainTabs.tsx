import React from "react";
import { Text } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import HomeScreen from "../screens/HomeScreen";
import MyObjectsScreen from "../screens/MyObjectsScreen";
import ProfileScreen from "../screens/ProfileScreen";

export type MainTabParamList = {
  Home: undefined;
  Analyser: undefined;
  MyObjects: undefined;
  Profile: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();

// Écran factice : cet onglet ne s'affiche jamais. Le listener ci-dessous
// intercepte l'appui et redirige vers "Capture", qui vit dans la pile
// racine au-dessus de la barre d'onglets (l'analyse ne doit pas avoir
// sa propre barre d'onglets pendant la capture/le résultat).
function AnalyzerPlaceholder() {
  return null;
}

const TAB_ICONS: Record<keyof MainTabParamList, string> = {
  Home: "🏠",
  Analyser: "📷",
  MyObjects: "📦",
  Profile: "👤",
};

const TAB_LABELS: Record<keyof MainTabParamList, string> = {
  Home: "Accueil",
  Analyser: "Analyser",
  MyObjects: "Mes objets",
  Profile: "Profil",
};

export default function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarLabel: TAB_LABELS[route.name as keyof MainTabParamList],
        tabBarIcon: () => (
          <Text style={{ fontSize: 20 }}>{TAB_ICONS[route.name as keyof MainTabParamList]}</Text>
        ),
        tabBarActiveTintColor: "#111827",
        tabBarInactiveTintColor: "#9CA3AF",
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen
        name="Analyser"
        component={AnalyzerPlaceholder}
        listeners={({ navigation }) => ({
          tabPress: (e) => {
            e.preventDefault();
            // Navigation vers la pile racine (hors barre d'onglets).
            (navigation.getParent() as any)?.navigate("Capture");
          },
        })}
      />
      <Tab.Screen name="MyObjects" component={MyObjectsScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}
