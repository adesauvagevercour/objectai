import fs from "fs";
import path from "path";
import crypto from "crypto";

// Interface volontairement minimale : le jour où l'app passe en production,
// on remplace LocalStorageService par une implémentation S3 (ou équivalent)
// sans toucher au reste du code (contrôleurs, etc.).
export interface StorageService {
  saveBase64Image(base64: string, prefix: string): Promise<string>; // retourne un chemin/URL public
  saveBase64File(base64: string, prefix: string): Promise<string>; // pour documents (image ou pdf)
}

const UPLOAD_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

function extensionFromDataUrl(base64: string, fallback: string): { ext: string; data: string } {
  const match = base64.match(/^data:([\w.-]+\/[\w.+-]+);base64,(.*)$/s);
  if (!match) {
    return { ext: fallback, data: base64 };
  }
  const mimeType = match[1];
  const data = match[2];
  if (mimeType === "application/pdf") return { ext: "pdf", data };
  const imageExt = mimeType.split("/")[1];
  return { ext: imageExt || fallback, data };
}

class LocalStorageService implements StorageService {
  async saveBase64Image(base64: string, prefix: string): Promise<string> {
    const { ext, data } = extensionFromDataUrl(base64, "jpg");
    const filename = `${prefix}-${crypto.randomUUID()}.${ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, filename), Buffer.from(data, "base64"));
    return `/uploads/${filename}`;
  }

  async saveBase64File(base64: string, prefix: string): Promise<string> {
    const { ext, data } = extensionFromDataUrl(base64, "bin");
    const filename = `${prefix}-${crypto.randomUUID()}.${ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, filename), Buffer.from(data, "base64"));
    return `/uploads/${filename}`;
  }
}

export const storageService: StorageService = new LocalStorageService();
