import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export type ObjectCondition = "neuf" | "tres_bon_etat" | "bon_etat" | "usage" | "mauvais_etat";

export interface EstimatedValue {
  min: number;
  max: number;
  currency: string;
  confidence: number; // 0-1
  factors: string[];
}

export interface AnalyzedObjectDraft {
  name: string;
  brand: string | null;
  model: string | null;
  category: string;
  description: string;
  characteristics: string[];
  condition: ObjectCondition;
  estimatedValue: EstimatedValue | null;
  confidenceScore: number; // 0-1
}

const SYSTEM_PROMPT = `Tu es un expert en identification d'objets (marques, modèles, état, valeur de revente).
On te fournit la photo d'un objet. Réponds UNIQUEMENT avec un objet JSON valide, sans texte autour,
sans balises markdown, respectant exactement ce schéma :

{
  "name": string,
  "brand": string | null,
  "model": string | null,
  "category": string,
  "description": string (2-3 phrases),
  "characteristics": string[] (caractéristiques visibles),
  "condition": "neuf" | "tres_bon_etat" | "bon_etat" | "usage" | "mauvais_etat",
  "estimatedValue": { "min": number, "max": number, "currency": "EUR", "confidence": number, "factors": string[] } | null,
  "confidenceScore": number (0 à 1, confiance globale sur l'identification)
}

Si tu ne peux pas estimer la valeur avec suffisamment de certitude, mets "estimatedValue" à null plutôt que d'inventer un chiffre.
Sois honnête sur l'incertitude via confidenceScore.`;

function stripDataUrlPrefix(base64: string): { mediaType: string; data: string } {
  const match = base64.match(/^data:(image\/\w+);base64,(.*)$/s);
  if (match) {
    return { mediaType: match[1], data: match[2] };
  }
  return { mediaType: "image/jpeg", data: base64 };
}

export async function analyzeImageWithAI(base64Image: string): Promise<AnalyzedObjectDraft> {
  const { mediaType, data } = stripDataUrlPrefix(base64Image);

  const response = await client.messages.create({
    model: "claude-sonnet-5",
    max_tokens: 1024,
    system: SYSTEM_PROMPT,
    messages: [
      {
        role: "user",
        content: [
          {
            type: "image",
            source: {
              type: "base64",
              media_type: mediaType as "image/jpeg" | "image/png" | "image/webp" | "image/gif",
              data,
            },
          },
          {
            type: "text",
            text: "Identifie cet objet et réponds uniquement avec le JSON demandé, rien d'autre.",
          },
        ],
      },
    ],
  });

  const textBlock = response.content.find((block) => block.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("Réponse IA vide ou invalide.");
  }

  let parsed: AnalyzedObjectDraft;
  try {
    parsed = JSON.parse(textBlock.text.trim());
  } catch {
    throw new Error("La réponse IA n'était pas un JSON valide.");
  }

  return parsed;
}

export interface PurchaseAnalysis {
  verdict: string;
  isGoodPrice: boolean | null;
  estimatedValue: EstimatedValue | null;
  pointsToCheck: string[];
  questionsForSeller: string[];
  valueRiskFactors: string[];
}

const PURCHASE_SYSTEM_PROMPT = `Tu es un expert qui aide un particulier à décider s'il doit acheter un objet
d'occasion, à partir d'une photo de l'objet ou de l'annonce. Réponds UNIQUEMENT avec un objet JSON valide,
sans texte autour, respectant exactement ce schéma :

{
  "verdict": string (2-3 phrases, avis global honnête),
  "isGoodPrice": boolean | null (null si le prix demandé n'est pas fourni ou pas déterminable),
  "estimatedValue": { "min": number, "max": number, "currency": "EUR", "confidence": number, "factors": string[] } | null,
  "pointsToCheck": string[] (points à vérifier avant l'achat),
  "questionsForSeller": string[] (questions concrètes à poser au vendeur),
  "valueRiskFactors": string[] (éléments visibles qui pourraient diminuer la valeur ou signaler un problème)
}`;

export async function analyzePurchase(
  base64Image: string,
  askingPrice?: number
): Promise<PurchaseAnalysis> {
  const { mediaType, data } = stripDataUrlPrefix(base64Image);

  const priceContext = askingPrice
    ? `Le vendeur demande ${askingPrice} EUR. Dis si c'est un prix intéressant.`
    : "Aucun prix n'est indiqué : mets isGoodPrice à null.";

  const response = await client.messages.create({
    model: "claude-sonnet-5",
    max_tokens: 1024,
    system: PURCHASE_SYSTEM_PROMPT,
    messages: [
      {
        role: "user",
        content: [
          {
            type: "image",
            source: {
              type: "base64",
              media_type: mediaType as "image/jpeg" | "image/png" | "image/webp" | "image/gif",
              data,
            },
          },
          { type: "text", text: `${priceContext} Réponds uniquement avec le JSON demandé.` },
        ],
      },
    ],
  });

  const textBlock = response.content.find((block) => block.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("Réponse IA vide ou invalide.");
  }

  try {
    return JSON.parse(textBlock.text.trim()) as PurchaseAnalysis;
  } catch {
    throw new Error("La réponse IA n'était pas un JSON valide.");
  }
}

export interface ListingDraft {
  title: string;
  description: string;
  mainCharacteristics: string[];
  condition: ObjectCondition;
  accessoriesIncluded: string[];
  importantNotes: string[];
  suggestedPrice: { min: number; max: number; currency: string };
}

const LISTING_SYSTEM_PROMPT = `Tu es un expert en rédaction d'annonces de vente pour des objets d'occasion.
On te fournit la fiche d'un objet (JSON). Réponds UNIQUEMENT avec un objet JSON valide, sans texte autour,
respectant exactement ce schéma :

{
  "title": string (accrocheur, concis, incluant marque/modèle si connus),
  "description": string (3-5 phrases, honnête, met en valeur l'objet sans exagérer),
  "mainCharacteristics": string[],
  "condition": "neuf" | "tres_bon_etat" | "bon_etat" | "usage" | "mauvais_etat",
  "accessoriesIncluded": string[] (vide si inconnu),
  "importantNotes": string[] (informations importantes à préciser à l'acheteur, ex: défauts, absence de boîte),
  "suggestedPrice": { "min": number, "max": number, "currency": "EUR" }
}`;

export async function generateListing(objectData: {
  name: string;
  brand: string | null;
  model: string | null;
  category: string;
  description: string;
  characteristics: string[];
  condition: ObjectCondition;
  estimatedValueMin: number | null;
  estimatedValueMax: number | null;
}): Promise<ListingDraft> {
  const response = await client.messages.create({
    model: "claude-sonnet-5",
    max_tokens: 1024,
    system: LISTING_SYSTEM_PROMPT,
    messages: [
      {
        role: "user",
        content: `Fiche objet : ${JSON.stringify(objectData)}. Réponds uniquement avec le JSON demandé.`,
      },
    ],
  });

  const textBlock = response.content.find((block) => block.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("Réponse IA vide ou invalide.");
  }

  try {
    return JSON.parse(textBlock.text.trim()) as ListingDraft;
  } catch {
    throw new Error("La réponse IA n'était pas un JSON valide.");
  }
}
