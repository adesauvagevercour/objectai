import { Response, Request } from "express";
import { z } from "zod";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { analyzeImageWithAI, generateListing } from "../services/ai.service";
import { storageService } from "../services/storage.service";
import { prisma } from "../lib/prisma";
import { findOwnedObject } from "../lib/ownership";

const analyzeSchema = z.object({
  // base64, avec ou sans préfixe data URL
  image: z.string().min(100, "Image manquante ou invalide."),
});

export async function analyzeObject(req: AuthenticatedRequest, res: Response) {
  const parsed = analyzeSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }

  try {
    const draft = await analyzeImageWithAI(parsed.data.image);

    await prisma.aiAnalysisLog.create({
      data: { userId: req.userId!, feature: "object_analysis", status: "success" },
    });

    return res.json(draft);
  } catch (err) {
    await prisma.aiAnalysisLog.create({
      data: { userId: req.userId!, feature: "object_analysis", status: "error" },
    });

    console.error("Erreur d'analyse IA:", err);
    return res.status(502).json({
      error: "L'analyse de la photo a échoué. Réessayez avec une photo plus nette.",
    });
  }
}

const estimatedValueSchema = z.object({
  min: z.number(),
  max: z.number(),
  currency: z.string(),
  confidence: z.number(),
  factors: z.array(z.string()),
});

const createObjectSchema = z.object({
  photoBase64: z.string().min(100),
  name: z.string().min(1),
  brand: z.string().nullable().optional(),
  model: z.string().nullable().optional(),
  category: z.string().min(1),
  description: z.string(),
  characteristics: z.array(z.string()).default([]),
  condition: z.enum(["neuf", "tres_bon_etat", "bon_etat", "usage", "mauvais_etat"]),
  estimatedValue: estimatedValueSchema.nullable().optional(),
  confidenceScore: z.number(),
});

function absoluteUrl(req: Request, relativePath: string) {
  return `${req.protocol}://${req.get("host")}${relativePath}`;
}

// Reconstitue le format "plat" stocké en base vers le format imbriqué utilisé côté client.
function serializeObject(req: Request, object: any) {
  return {
    id: object.id,
    photoUrl: absoluteUrl(req, object.photoUrl),
    name: object.name,
    brand: object.brand,
    model: object.model,
    category: object.category,
    description: object.description,
    characteristics: object.characteristics,
    condition: object.condition,
    estimatedValue:
      object.estimatedValueMin != null
        ? {
            min: object.estimatedValueMin,
            max: object.estimatedValueMax,
            currency: object.estimatedValueCurrency,
            factors: object.estimatedValueFactors,
            confidence: object.confidenceScore,
          }
        : null,
    confidenceScore: object.confidenceScore,
    createdAt: object.createdAt,
    updatedAt: object.updatedAt,
    history: object.history
      ? object.history.map((h: any) => ({
          id: h.id,
          date: h.date,
          label: h.label,
          estimatedValue:
            h.estimatedValueMin != null ? { min: h.estimatedValueMin, max: h.estimatedValueMax } : null,
        }))
      : undefined,
    documents: object.documents
      ? object.documents.map((d: any) => ({
          id: d.id,
          type: d.type,
          fileUrl: absoluteUrl(req, d.fileUrl),
          createdAt: d.createdAt,
        }))
      : undefined,
    reminders: object.reminders
      ? object.reminders.map((r: any) => ({
          id: r.id,
          message: r.message,
          dueAt: r.dueAt,
        }))
      : undefined,
  };
}

export async function createObject(req: AuthenticatedRequest, res: Response) {
  const parsed = createObjectSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }
  const d = parsed.data;

  const photoUrl = await storageService.saveBase64Image(d.photoBase64, "object");

  const object = await prisma.analyzedObject.create({
    data: {
      ownerId: req.userId!,
      photoUrl,
      name: d.name,
      brand: d.brand ?? null,
      model: d.model ?? null,
      category: d.category,
      description: d.description,
      characteristics: d.characteristics,
      condition: d.condition,
      estimatedValueMin: d.estimatedValue?.min,
      estimatedValueMax: d.estimatedValue?.max,
      estimatedValueCurrency: d.estimatedValue?.currency ?? "EUR",
      estimatedValueFactors: d.estimatedValue?.factors ?? [],
      confidenceScore: d.confidenceScore,
      history: {
        create: {
          label: "Analyse initiale",
          estimatedValueMin: d.estimatedValue?.min,
          estimatedValueMax: d.estimatedValue?.max,
        },
      },
    },
    include: { history: true },
  });

  return res.status(201).json(serializeObject(req, object));
}

export async function listObjects(req: AuthenticatedRequest, res: Response) {
  const objects = await prisma.analyzedObject.findMany({
    where: { ownerId: req.userId },
    orderBy: { updatedAt: "desc" },
  });
  return res.json(objects.map((o: (typeof objects)[number]) => serializeObject(req, o)));
}

export async function getObject(req: AuthenticatedRequest, res: Response) {
  const object = await prisma.analyzedObject.findFirst({
    where: { id: req.params.id, ownerId: req.userId },
    include: { history: { orderBy: { date: "desc" } }, documents: true, reminders: true },
  });
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }
  return res.json(serializeObject(req, object));
}

export async function generateListingForObject(req: AuthenticatedRequest, res: Response) {
  const object = await findOwnedObject(req.params.id, req.userId!);
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }

  try {
    const listing = await generateListing({
      name: object.name,
      brand: object.brand,
      model: object.model,
      category: object.category,
      description: object.description,
      characteristics: object.characteristics,
      condition: object.condition as any,
      estimatedValueMin: object.estimatedValueMin,
      estimatedValueMax: object.estimatedValueMax,
    });

    await prisma.aiAnalysisLog.create({
      data: { userId: req.userId!, feature: "sale_listing", status: "success" },
    });

    return res.json(listing);
  } catch (err) {
    await prisma.aiAnalysisLog.create({
      data: { userId: req.userId!, feature: "sale_listing", status: "error" },
    });

    console.error("Erreur de génération d'annonce:", err);
    return res.status(502).json({ error: "La génération de l'annonce a échoué. Réessayez." });
  }
}
