import { Response } from "express";
import { z } from "zod";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { analyzePurchase } from "../services/ai.service";
import { prisma } from "../lib/prisma";

const analyzePurchaseSchema = z.object({
  image: z.string().min(100, "Image manquante ou invalide."),
  askingPrice: z.number().positive().optional(),
});

export async function analyzePurchaseController(req: AuthenticatedRequest, res: Response) {
  const parsed = analyzePurchaseSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }

  try {
    const result = await analyzePurchase(parsed.data.image, parsed.data.askingPrice);

    await prisma.aiAnalysisLog.create({
      data: { userId: req.userId!, feature: "purchase_check", status: "success" },
    });

    return res.json(result);
  } catch (err) {
    await prisma.aiAnalysisLog.create({
      data: { userId: req.userId!, feature: "purchase_check", status: "error" },
    });

    console.error("Erreur d'analyse d'achat:", err);
    return res.status(502).json({
      error: "L'analyse a échoué. Réessayez avec une photo plus nette.",
    });
  }
}
