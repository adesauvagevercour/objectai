import { Response } from "express";
import { z } from "zod";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { storageService } from "../services/storage.service";
import { prisma } from "../lib/prisma";
import { findOwnedObject } from "../lib/ownership";

const DOCUMENT_TYPES = ["facture", "notice", "certificat", "garantie", "photo", "autre"] as const;

const addDocumentSchema = z.object({
  type: z.enum(DOCUMENT_TYPES),
  fileBase64: z.string().min(50),
});

export async function addDocument(req: AuthenticatedRequest, res: Response) {
  const object = await findOwnedObject(req.params.id, req.userId!);
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }

  const parsed = addDocumentSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }

  const fileUrl = await storageService.saveBase64File(parsed.data.fileBase64, "document");

  const document = await prisma.document.create({
    data: { objectId: object.id, type: parsed.data.type, fileUrl },
  });

  return res.status(201).json({
    id: document.id,
    type: document.type,
    fileUrl: `${req.protocol}://${req.get("host")}${document.fileUrl}`,
    createdAt: document.createdAt,
  });
}

export async function listDocuments(req: AuthenticatedRequest, res: Response) {
  const object = await findOwnedObject(req.params.id, req.userId!);
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }

  const documents = await prisma.document.findMany({
    where: { objectId: object.id },
    orderBy: { createdAt: "desc" },
  });

  return res.json(
    documents.map((d: (typeof documents)[number]) => ({
      id: d.id,
      type: d.type,
      fileUrl: `${req.protocol}://${req.get("host")}${d.fileUrl}`,
      createdAt: d.createdAt,
    }))
  );
}

export async function deleteDocument(req: AuthenticatedRequest, res: Response) {
  const object = await findOwnedObject(req.params.id, req.userId!);
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }

  const document = await prisma.document.findFirst({
    where: { id: req.params.docId, objectId: object.id },
  });
  if (!document) {
    return res.status(404).json({ error: "Document introuvable." });
  }

  await prisma.document.delete({ where: { id: document.id } });
  return res.status(204).send();
}
