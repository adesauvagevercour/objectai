import { Response } from "express";
import { z } from "zod";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { prisma } from "../lib/prisma";
import { findOwnedObject } from "../lib/ownership";

const addReminderSchema = z.object({
  message: z.string().min(1),
  dueAt: z.string().datetime({ offset: true }).or(z.string().min(1)), // ISO 8601
});

export async function addReminder(req: AuthenticatedRequest, res: Response) {
  const object = await findOwnedObject(req.params.id, req.userId!);
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }

  const parsed = addReminderSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }

  const dueAt = new Date(parsed.data.dueAt);
  if (isNaN(dueAt.getTime())) {
    return res.status(400).json({ error: "Date de rappel invalide." });
  }

  const reminder = await prisma.reminder.create({
    data: { objectId: object.id, message: parsed.data.message, dueAt },
  });

  return res.status(201).json({ id: reminder.id, message: reminder.message, dueAt: reminder.dueAt });
}

export async function listReminders(req: AuthenticatedRequest, res: Response) {
  const object = await findOwnedObject(req.params.id, req.userId!);
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }

  const reminders = await prisma.reminder.findMany({
    where: { objectId: object.id },
    orderBy: { dueAt: "asc" },
  });

  return res.json(reminders.map((r: (typeof reminders)[number]) => ({ id: r.id, message: r.message, dueAt: r.dueAt })));
}

export async function deleteReminder(req: AuthenticatedRequest, res: Response) {
  const object = await findOwnedObject(req.params.id, req.userId!);
  if (!object) {
    return res.status(404).json({ error: "Objet introuvable." });
  }

  const reminder = await prisma.reminder.findFirst({
    where: { id: req.params.reminderId, objectId: object.id },
  });
  if (!reminder) {
    return res.status(404).json({ error: "Rappel introuvable." });
  }

  await prisma.reminder.delete({ where: { id: reminder.id } });
  return res.status(204).send();
}
