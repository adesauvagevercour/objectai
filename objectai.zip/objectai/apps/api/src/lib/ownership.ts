import { prisma } from "./prisma";

export async function findOwnedObject(objectId: string, ownerId: string) {
  return prisma.analyzedObject.findFirst({ where: { id: objectId, ownerId } });
}
