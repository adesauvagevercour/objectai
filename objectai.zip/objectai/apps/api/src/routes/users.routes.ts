import { Router } from "express";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.middleware";
import { prisma } from "../lib/prisma";

const router = Router();

router.get("/me", requireAuth, async (req: AuthenticatedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  if (!user) return res.status(404).json({ error: "Utilisateur introuvable." });
  return res.json({ id: user.id, email: user.email, name: user.name, createdAt: user.createdAt });
});

export default router;
