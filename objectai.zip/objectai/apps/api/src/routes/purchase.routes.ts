import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware";
import { analyzePurchaseController } from "../controllers/purchase.controller";

const router = Router();

router.post("/analyze", requireAuth, analyzePurchaseController);

export default router;
