import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware";
import {
  analyzeObject,
  createObject,
  listObjects,
  getObject,
  generateListingForObject,
} from "../controllers/objects.controller";
import { addDocument, listDocuments, deleteDocument } from "../controllers/documents.controller";
import { addReminder, listReminders, deleteReminder } from "../controllers/reminders.controller";

const router = Router();

router.post("/analyze", requireAuth, analyzeObject);
router.post("/", requireAuth, createObject);
router.get("/", requireAuth, listObjects);
router.get("/:id", requireAuth, getObject);
router.post("/:id/listing", requireAuth, generateListingForObject);

router.post("/:id/documents", requireAuth, addDocument);
router.get("/:id/documents", requireAuth, listDocuments);
router.delete("/:id/documents/:docId", requireAuth, deleteDocument);

router.post("/:id/reminders", requireAuth, addReminder);
router.get("/:id/reminders", requireAuth, listReminders);
router.delete("/:id/reminders/:reminderId", requireAuth, deleteReminder);

export default router;
