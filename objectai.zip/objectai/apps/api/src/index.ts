import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import authRoutes from "./routes/auth.routes";
import usersRoutes from "./routes/users.routes";
import objectsRoutes from "./routes/objects.routes";
import purchaseRoutes from "./routes/purchase.routes";

const app = express();

app.use(cors());
// Limite augmentée pour accepter les photos encodées en base64.
app.use(express.json({ limit: "12mb" }));

app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.get("/health", (_req, res) => res.json({ status: "ok" }));

app.use("/auth", authRoutes);
app.use("/users", usersRoutes);
app.use("/objects", objectsRoutes);
app.use("/purchase", purchaseRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`ObjectAI API démarrée sur le port ${PORT}`);
});
