export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface AuthResponse {
  user: User;
  tokens: AuthTokens;
}

export type ObjectCondition = "neuf" | "tres_bon_etat" | "bon_etat" | "usage" | "mauvais_etat";

export interface EstimatedValue {
  min: number;
  max: number;
  currency: string;
  confidence: number; // 0-1
  factors: string[];
}

export interface AnalyzedObject {
  id: string;
  ownerId: string;
  photoUrl: string;
  name: string;
  brand?: string;
  model?: string;
  category: string;
  description: string;
  characteristics: string[];
  condition: ObjectCondition;
  estimatedValue?: EstimatedValue;
  confidenceScore: number; // 0-1, confiance globale de l'identification
  createdAt: string;
  updatedAt: string;
}

export interface ObjectHistoryEntry {
  id: string;
  objectId: string;
  date: string;
  label: string;
  estimatedValue?: EstimatedValue;
}
